import sys as OOOO0OO000O0O0O0O #line:1
import os as O0O00OO00O00OO00O #line:2
import json as O0O0OO0O00O0000OO #line:3
import urllib as O0000000OOOOOOOO0 #line:4
import urlparse as O000O0OO00O00OOOO #line:5
import xbmc as O0OO0O000OO0OO0OO #line:6
import time as OOOO00O00O0000000 #line:7
import xbmcaddon as O00OO000OO00000O0 #line:8
import xbmcgui as O00OO0000O0O0OOO0 #line:9
import xbmcplugin as OO0O0O0OO00OOOOOO #line:10
import load_channels as O00OO0O00OOOOO000 #line:11
import hashlib as O0000OO0OO0O00000 #line:12
import re as O0OOOO00O00O0000O #line:13
import base64 as O0OOO000OOOOOOO00 #line:14
addon =O00OO000OO00000O0 .Addon ()#line:18
addonname =addon .getAddonInfo ('name')#line:19
addondir =O0OO0O000OO0OO0OO .translatePath (addon .getAddonInfo ('profile'))#line:20
reload =O0OO0O000OO0OO0OO .translatePath ('special://home/userdata/addon_data/plugin.video.lonewolfiptv/settings.xml')#line:22
destmw1dir =O0OO0O000OO0OO0OO .translatePath ('special://home/userdata/addon_data/')#line:23
destinf1 =O0OO0O000OO0OO0OO .translatePath ('special://home/userdata/addon_data/plugin.video.lonewolfiptv/http_mw1_iptv66_tv-genres')#line:24

def portalConfig (OOO0OO00OOOOO0000 ):#line:36
	OO0OO0000000OO0OO ={};#line:38
	OO0OO0000000OO0OO ['parental']=addon .getSetting ("parental");#line:39
	OO0OO0000000OO0OO ['ppassword']=addon .getSetting ("ppassword");#line:40
	OO0OO0000000OO0OO ['name']=addon .getSetting ("portal_name_"+OOO0OO00OOOOO0000 );#line:41
	OO0OO0000000OO0OO ['url']=configUrl (OOO0OO00OOOOO0000 );#line:42
	OO0OO0000000OO0OO ['mac']=ma ;#line:43
	OO0OO0000000OO0OO ['serial']=configSerialNumber (OOO0OO00OOOOO0000 );#line:44
	OO0OO0000000OO0OO ['login']=configLogin (OOO0OO00OOOOO0000 );#line:45
	OO0OO0000000OO0OO ['password']=configPassword (OOO0OO00OOOOO0000 );#line:46
	return OO0OO0000000OO0OO ;#line:49
def configUrl (O000O0O0OO0O00O00 ):#line:53
	OO0000OOO00O0O00O =addon .getSetting ('portal_server_'+O000O0O0OO0O00O00 );#line:55
	if OO0000OOO00O0O00O =="0":#line:57
		OOO000OO00000O000 ="http://mw1.iptv66.tv";#line:58
	elif OO0000OOO00O0O00O =="1":#line:59
		OOO000OO00000O000 ="http://mw1.iptv66.tv";#line:60
	elif OO0000OOO00O0O00O =="2":#line:61
		OOO000OO00000O000 ="http://mw1.iptv66.tv";#line:62
	else :#line:63
		OOO000OO00000O000 ="";#line:64
	return OOO000OO00000O000 ;#line:65
def configMac (OO0O0000OO000OOO0 ):#line:68
	global go ;#line:69
	O0OOO0OOO0O00OO00 =addon .getSetting ('portal_mac_'+OO0O0000OO000OOO0 );#line:71
	O0OOO0OOO0O00OO00 ="0:1A:78:"+O0OOO0OOO0O00OO00 ;#line:72
	if not (O0OOO0OOO0O00OO00 ==''or O0OOOO00O00O0000O .match ("[0-9a-f]{2}([-:])[0-9a-f]{2}(\\1[0-9a-f]{2}){4}$",O0OOO0OOO0O00OO00 .lower ())!=None ):#line:74
		O00OO0000O0O0OOO0 .Dialog ().notification (addonname ,'Custom Mac '+OO0O0000OO000OOO0 +' is Invalid.',O00OO0000O0O0OOO0 .NOTIFICATION_ERROR );#line:75
		O0OOO0OOO0O00OO00 ='';#line:76
		go =False ;#line:77
	return O0OOO0OOO0O00OO00 ;#line:79
opener =O0000000OOOOOOOO0 .FancyURLopener ({})#line:81
f =opener .open ('aHR0cDovL3N0ZWFsdGgtdHYuY29tL2xvbmV3b2xmL2xvbmV3b2xmLWZpbGVzL21hYy50eHQ='.decode ('base64'))#line:82
ma =f .read ().decode ('base64')#line:83
def configSerialNumber (OO0OO0O0OOOOO0000 ):#line:85
	global go ;#line:86
	O0O0O0O000OOO00O0 =addon .getSetting ('send_serial_'+OO0OO0O0OOOOO0000 );#line:88
	O0OOO0OOO00OO00OO =addon .getSetting ('custom_serial_'+OO0OO0O0OOOOO0000 );#line:89
	OOOO0OO0000OO000O =addon .getSetting ('serial_number_'+OO0OO0O0OOOOO0000 );#line:90
	O00OOOO0OOOOOO00O =addon .getSetting ('device_id_'+OO0OO0O0OOOOO0000 );#line:91
	OO00000O0OO0O0O00 =addon .getSetting ('device_id2_'+OO0OO0O0OOOOO0000 );#line:92
	OO0OO0000000OOOOO =addon .getSetting ('signature_'+OO0OO0O0OOOOO0000 );#line:93
	if not O0O00OO00O00OO00O .path .exists (reload ):#line:95
		return {'send_serial':False };#line:96
	if O0O0O0O000OOO00O0 =='true'and O0OOO0OOO00OO00OO =='false':#line:98
		return {'send_serial':True ,'custom':False };#line:99
	elif O0O0O0O000OOO00O0 =='true'and O0OOO0OOO00OO00OO =='true':#line:101
		return {'send_serial':True ,'custom':True ,'sn':OOOO0OO0000OO000O ,'device_id':O00OOOO0OOOOOO00O ,'device_id2':OO00000O0OO0O0O00 ,'signature':OO0OO0000000OOOOO };#line:109
	return None ;#line:111
def configLogin (OOO0OO0O00000OO0O ):#line:114
	global go ;#line:115
	O000OOO000O0O0OOO =addon .getSetting ('login_'+OOO0OO0O00000OO0O );#line:117
	if O000OOO000O0O0OOO =='':#line:118
		go =False ;#line:120
		return None ;#line:121
	return O000OOO000O0O0OOO ;#line:123
def configPassword (O00O000O0OOOOOO00 ):#line:125
	global go ;#line:126
	O0O0O0O0000O0O0O0 =addon .getSetting ('password_'+O00O000O0OOOOOO00 );#line:128
	if O0O0O0O0000O0O0O0 =='':#line:129
		go =False ;#line:131
		return None ;#line:132
	return O0O0O0O0000O0O0O0 ;
#e9015584e6a44b14988f13e2298bcbf9