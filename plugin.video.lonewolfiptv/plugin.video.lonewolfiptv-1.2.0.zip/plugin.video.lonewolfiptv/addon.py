import sys
import os
import json
import urllib
import urllib2
import urlparse
import xbmcaddon
import xbmcgui
import xbmcplugin
import hashlib
import re
import errno
import time
import getpass
from json import load
import config
import shutil
import load_channels
import server
import net
from urllib2 import HTTPPasswordMgrWithDefaultRealm, HTTPBasicAuthHandler, build_opener, install_opener, urlopen, HTTPError


 

addon       = xbmcaddon.Addon()
addonname   = addon.getAddonInfo('name')
addon_id = 'plugin.video.lonewolfiptv'
selfAddon = xbmcaddon.Addon(id=addon_id)
addondir    = xbmc.translatePath( addon.getAddonInfo('profile') ) 

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
plugin_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
dialog = xbmcgui.Dialog()
net = net.Net()



fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'images/fanart1.jpg'))
fanart2 = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'images/fanart2.jpg'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon1.png'))
icon2 = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon2.png'))
reload = xbmc.translatePath('special://home/userdata/addon_data/plugin.video.lonewolfiptv/settings.xml')
destmw1dir2 = xbmc.translatePath('special://home/userdata/addon_data/')
destmw1dir = xbmc.translatePath('special://home/userdata/addon_data/plugin.video.lonewolfiptv/')
destinf1 = xbmc.translatePath('special://home/userdata/addon_data/plugin.video.lonewolfiptv/http_mw1_iptv66_tv-genres')
destinf2 = xbmc.translatePath('special://home/userdata/addon_data/plugin.video.lonewolfiptv/http_mw1_iptv66_tv')




 
   

suser = selfAddon.getSetting('username')
spass = selfAddon.getSetting('spassword')


 
go= True;

	
xbmcplugin.setContent(addon_handle, 'movies')

     

def Main():
  if not os.path.exists(destinf1):
    
    addDir('[COLOR orange]CLICK HERE TO LOGIN[/COLOR]','0',3008,icon, fanart)
  if  os.path.exists(destinf1): 
   
    addDir('[COLOR orange]CLICK HERE TO LOGOUT[/COLOR]','0',3009,icon, fanart2)
    
    
xbmc.executebuiltin('Container.SetViewMode(50)')
	
	


def Login():
	if not os.path.exists(destmw1dir):
		try: 
			os.makedirs(destmw1dir)
		except OSError as exception:
			if not os.path.isdir(destmw1dir):
				pass

	if not suser == '' or spass == '':
		ret = dialog.yesno('Welcome To Lone Wolf IPTV', '                  Please enter your username & password','','','Cancel','Enter')
		if ret == 1:
			keyb = xbmc.Keyboard('', 'Enter Username')
			keyb.doModal()
			if (keyb.isConfirmed()):
				search = keyb.getText()
				username=search
				keyb = xbmc.Keyboard('', 'Enter Password:')
				keyb.doModal()
				if (keyb.isConfirmed()):
					search = keyb.getText()
					password=search
					selfAddon.setSetting('username',username)
					selfAddon.setSetting('spassword',password)
					username = selfAddon.getSetting('username')
					password = selfAddon.getSetting('spassword')
					dir = xbmc.translatePath('special://home/userdata/addon_data/plugin.video.lonewolfiptv/')
					url = 'http://stealth-tv.com/lonewolf/lonewolf/http_mw1_iptv66_tv'
					url2 = 'http://stealth-tv.com/lonewolf/lonewolf/http_mw1_iptv66_tv-genres'
					print("calling %s with %s:%s\n" % (url, username, password))
					print("calling %s with %s:%s\n" % (url2, username, password))

					passman = urllib2.HTTPPasswordMgrWithDefaultRealm()
					passman.add_password(None, url, username, password)
					passman.add_password(None, url2, username, password)
					urllib2.install_opener(urllib2.build_opener(urllib2.HTTPBasicAuthHandler(passman)))

					req = urllib2.Request(url)
					f = urllib2.urlopen(req)
					data = f.read()
					with open(dir + "http_mw1_iptv66_tv", "wb") as code:
						code.write(data)
					if  os.path.exists(destinf2):
						dialog.ok(addon_id, '[COLOR white]Username & Password Entered successfully, Please exit & Re-Launch[/COLOR]')	
	                   
					req = urllib2.Request(url2)
					f = urllib2.urlopen(req)
					data2 = f.read()
					with open(dir + "http_mw1_iptv66_tv-genres", "wb") as code:
						code.write(data2)
					if not os.path.exists(destinf1):
						dialog.ok(addon_id, '[COLOR white]Username & Password Entered successfully, Enjoy Lone Wolf IPTV/COLOR]')	
								         
					

def Logout():
	try:
		os.remove(reload)
		os.remove(destinf1)
		os.remove(destinf2)
		

		
		
	except OSError:
		pass
		dialog.ok(addon_id, '[COLOR white]You are now logged out, Please log back in to enjoy Lone Wolf IPTV[/COLOR]')
		
		

		
		
def addDir(name,url,mode,iconimage,fanart,description=''): 
		u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&description="+str(description)
		ok=True
		liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
		liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
		liz.setProperty('fanart_image', fanart)
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
		
		return ok

def get_params():
		param=[]
		paramstring=sys.argv[2]
		if len(paramstring)>=2:
				e4=sys.argv[2]
				cleanedparams=e4.replace('?','')
				if (e4[len(e4)-1]=='/'):
						e4=e4[0:len(e4)-2]
				pairsofparams=cleanedparams.split('&')
				param={}
				for i in range(len(pairsofparams)):
						splitparams={}
						splitparams=pairsofparams[i].split('=')
						if (len(splitparams))==2:
								param[splitparams[0]]=splitparams[1]	
		return param
		   
e4=get_params()
url=None
name=None
mode=None
iconimage=icon
description=None

try:url=urllib.unquote_plus(e4["url"])
except:pass
try:name=urllib.unquote_plus(e4["name"])
except:pass
try:mode=int(e4["mode"])
except:pass
try:iconimage=urllib.unquote_plus(e4["iconimage"])
except:pass

if mode==None or url==None or len(url)<1:Main()
elif mode==3008:Login()
elif mode==3009:Logout()


		
def addPortal(portal):

	if not os.path.exists(destinf1):
		dialog.ok(addon_id, '[I][COLOR white]You are not logged in, Please login to use this addon[/COLOR][/I]')


	if not os.path.exists(destinf1):
	
		return;

	url = build_url({
		'mode': 'genres', 
		'portal' : json.dumps(portal)
		});
	
	cmd = 'XBMC.RunPlugin(' + base_url + 'stalker_url=' + portal['url'] + ')';	
	
	li = xbmcgui.ListItem(portal['name'],icon, fanart)
	li.addContextMenuItems([ ('Clear Cache', cmd) ]);

	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);
	
	
	
def build_url(query):
	return base_url + '?' + urllib.urlencode(query)
	
	

def homeLevel():
	global portal_1, portal_2, portal_3, go;
	# at least portal 1 will be active.
	
	if go:
		addPortal(portal_1);
		xbmcplugin.endOfDirectory(addon_handle);


def genreLevel():
 if  os.path.exists(destinf1):
    	try:
		data = load_channels.getGenres(portal['mac'],portal['url'],portal['serial'],portal['login'],portal['password'],addondir);
		
	except Exception as e:
		xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR );
		
		return;

	data = data['genres'];

	for id, i in data.iteritems():

		title 	= i["title"];
		
		url = build_url({
			'mode': 'channels', 
			'genre_id': id, 
			'genre_name': title.title(), 
			'portal' : json.dumps(portal)
			});
		
		if id == '10':
			iconImage = 'OverlayLocked.png';
		else:
			iconImage = 'DefaultVideo.png';
			
		li = xbmcgui.ListItem(title.title(),icon, fanart)
		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);
		
##########
# create VoD folder
#	url = build_url({
#		'mode': 'vod', 
#		'portal' : json.dumps(portal)
#		});
#			
#	li = xbmcgui.ListItem('VoD', iconImage='DefaultVideo.png')
#	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);
##########			
		
	xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_LABEL);
	xbmcplugin.endOfDirectory(addon_handle);

def vodLevel():
	
	try:
		data = load_channels.getVoD(portal['mac'], portal['url'], portal['serial'], portal['login'], portal['password'], addondir);
		
	except Exception as e:
		xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR );
		return;
	
	data = data['vod'];
	
	for i in data:
		name 	= i["name"];
		cmd 	= i["cmd"];
		logo 	= i["logo"];
		
		if logo != '':
			logo_url = portal['url'] + logo;
		else:
			logo_url = 'special://home/addons/plugin.video.lonewolfiptv/icon.png';
				
		url = build_url({
				'mode': 'play', 
				'cmd': cmd, 
				'tmp' : '0', 
				'title' : name.encode("utf-8"),
				'genre_name' : 'VoD',
				'logo_url' : logo_url, 
				'portal' : json.dumps(portal)
				});
			
		li = xbmcgui.ListItem(name, icon, fanart)
		li.setInfo(type='Video', infoLabels={ "Title": name })

		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
	xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_UNSORTED);
	xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);
	xbmcplugin.endOfDirectory(addon_handle);

def channelLevel():

	stop=False;
		
	try:
		data = load_channels.getAllChannels(portal['mac'], portal['url'], portal['serial'],portal['login'], portal['password'], addondir);
		
	except Exception as e:
		
		return;
		
	data = data['channels'];
	genre_name 	= args.get('genre_name', None);	
	genre_id_main = args.get('genre_id', None);
	genre_id_main = genre_id_main[0];
	
	if genre_id_main == '10' and portal['parental'] == 'true':
		result = xbmcgui.Dialog().input('Parental', hashlib.md5(portal['ppassword'].encode('utf-8')).hexdigest(), type=xbmcgui.INPUT_PASSWORD, option=xbmcgui.PASSWORD_VERIFY);
		if result == '':
			stop = True;
	
	if stop == False:
		for i in data.values():
			
			name 		= i["name"];
			cmd 		= i["cmd"];
			tmp 		= i["tmp"];
			number 		= i["number"];
			genre_id 	= i["genre_id"];
			logo 		= i["logo"];
		
			if genre_id_main == '*' and genre_id == '10' and portal['parental'] == 'true':
				continue;
				
			if genre_id_main == genre_id or genre_id_main == '*':
		
				if logo != '':
					logo_url = portal['url'] + '/stalker_portal/misc/logos/320/' + logo;
				else:
					logo_url = 'DefaultVideo.png';
								
				url = build_url({
					'mode': 'play', 
					'cmd': cmd, 
					'tmp' : tmp, 
					'title' : name.encode("utf-8"),
					'genre_name' : genre_name,
					'logo_url' : logo_url,  
					'portal' : json.dumps(portal)
					});
			
				li = xbmcgui.ListItem(name, iconImage=logo_url, thumbnailImage=logo_url);
				li.setInfo(type='Video', infoLabels={ 
					'title': name,
					'count' : number
					});

				xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li);
		
		
		xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);
		xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_PROGRAM_COUNT);
			
		xbmcplugin.endOfDirectory(addon_handle);

def playLevel():
	
	dp = xbmcgui.DialogProgressBG();
	dp.create('IPTV', 'Loading ...');
	
	title 	= args['title'][0];
	cmd 	= args['cmd'][0];
	tmp 	= args['tmp'][0];
	genre_name 	= args['genre_name'][0];
	logo_url 	= args['logo_url'][0];

	if genre_name == 'VoD' or genre_name == 'VoD Espanol':
		tmp = "";

	try :
		url = load_channels.retriveUrl(portal['mac'], portal['url'], portal['serial'], portal['login'], portal['password'], cmd, tmp);
			
	except Exception as e:
		dp.close();
		xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR );
		return;

	
	dp.update(80);
	
	title = title.decode("utf-8");
	
	title += ' (' + portal['name'] + ')';
	
	li = xbmcgui.ListItem(title, iconImage='DefaultVideo.png', thumbnailImage=logo_url);
	li.setInfo('video', {'Title': title, 'Genre': genre_name});
	xbmc.Player().play(item=url, listitem=li);
	
	dp.update(100);
	
	dp.close();


mode = args.get('mode', None);
portal =  args.get('portal', None)


mode = args.get('mode', None);
portal =  args.get('portal', None)


if portal is None:
	portal_1 = config.portalConfig('1');
	portal_2 = config.portalConfig('2');
	portal_3 = config.portalConfig('3');	

else:
#  Force outside call to portal_1
	portal = json.loads(portal[0]);
	portal_2 = config.portalConfig('2');
	portal_3 = config.portalConfig('3');	

	if not ( portal['name'] == portal_2['name'] or portal['name'] == portal_3['name'] ) :
		portal = config.portalConfig('1');


if mode is None:
	homeLevel();

elif mode[0] == 'cache':	
	stalker_url = args.get('stalker_url', None);
	stalker_url = stalker_url[0];	
	load_channels.clearCache(stalker_url, addondir);

elif mode[0] == 'genres':
	genreLevel();
		
elif mode[0] == 'vod':
	vodLevel();

elif mode[0] == 'channels':
	channelLevel();
	
elif mode[0] == 'play':
	playLevel();
	
elif mode[0] == 'server':
	port = addon.getSetting('server_port');
	
	action =  args.get('action', None);
	action = action[0];
	
	dp = xbmcgui.DialogProgressBG();
	dp.create('M3U Server', 'Working ...');
	
	if action == 'start':
	
		if server.serverOnline():
			xbmcgui.Dialog().notification(addonname, 'Server already started.\nPort: ' + str(port), xbmcgui.NOTIFICATION_INFO );
		else:
			server.startServer();
			time.sleep(5);
			if server.serverOnline():
				xbmcgui.Dialog().notification(addonname, 'Server started.\nPort: ' + str(port), xbmcgui.NOTIFICATION_INFO );
			else:
				xbmcgui.Dialog().notification(addonname, 'Server not started. Wait a minute and try again. ', xbmcgui.NOTIFICATION_ERROR );
				
	else:
		if server.serverOnline():
			server.stopServer();
			time.sleep(5);
			xbmcgui.Dialog().notification(addonname, 'Server stopped.', xbmcgui.NOTIFICATION_INFO );
		else:
			xbmcgui.Dialog().notification(addonname, 'Server is already stopped.', xbmcgui.NOTIFICATION_INFO );
			
			
		dp.close();
		
		
		
		
		